# BSI

BSI 결과보고서 : https://docs.google.com/presentation/d/1rpdMUGzOZHjGKg1giP0QGdzrVDW8LIfs/edit?usp=sharing&ouid=114494668405155711785&rtpof=true&sd=true

BSI 시연영상 : https://drive.google.com/file/d/1W9cCsZxtkJGhWi3E7eYYxurFZyeCrZtu/view?usp=sharing
